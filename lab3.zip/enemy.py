import pygame
import math
import os
from settings import PATH, RED, WHITE, BLACK, PURPLE, GREEN, PATH_OTHER


pygame.init()
ENEMY_IMAGE = pygame.image.load(os.path.join("images", "enemy.png"))

#決定是哪一條路線 
which_path = 0
class Enemy:
    
    #參數初始化
    def __init__(self):
        self.width = 40
        self.height = 50
        self.image = pygame.transform.scale(ENEMY_IMAGE, (self.width, self.height))
        self.health = 5
        self.max_health = 10
        #如果which是偶數走PATH，是奇數就走PATH_OTHER
        if which_path % 2 ==0 :
            self.path = PATH
        else:
            self.path = PATH_OTHER
        self.path_pos = 0
        self.move_count = 0
        self.stride = 1
        self.x, self.y = self.path[0]

    #畫出敵人
    def draw(self, win):
        # draw enemy
        win.blit(self.image, (self.x - self.width // 2, self.y - self.height // 2))
        # draw enemy health bar
        self.draw_health_bar(win)

    #畫出血條
    def draw_health_bar(self, win):
        """
        Draw health bar on an enemy
        :param win: window
        :return: None
        """
        #畫出綠色血條
        pygame.draw.rect(win, GREEN, [self.x - self.width // 2, self.y - self.height // 2, 40*(self.health / self.max_health), 5])
        #畫出紅色血條
        pygame.draw.rect(win, RED, [self.x, self.y - self.height // 2, 40*(self.health / self.max_health), 5])
        

    def move(self):
        global which_path
        """
        Enemy move toward path points every frame
        :return: None
        """
        #決定要計算的是
        if self.path == PATH:
            ax, ay = PATH[ self.path_pos ]  # x, y position of point A
            bx, by = PATH[ self.path_pos+1 ]
        else:
            ax, ay = PATH_OTHER[ self.path_pos ]  # x, y position of point A
            bx, by = PATH_OTHER[ self.path_pos+1 ]

        distance_A_B = math.sqrt((bx - ax)**2 + (by - ay)**2)
        max_count = int(distance_A_B / self.stride)  # total footsteps that needed from A to B
        
        #如果還沒到達下個點，步數就一直增加
        if self.move_count < max_count:
            unit_vector_x = (bx - ax) / distance_A_B
            unit_vector_y = (by - ay) / distance_A_B
            delta_x = unit_vector_x * self.stride
            delta_y = unit_vector_y * self.stride
            self.x += delta_x
            self.y += delta_y
            self.move_count += 1
            
        #換下一個點
        else:
            self.path_pos += 1
            self.move_count = 0
    
        #如果是PATH且到達基地就將 self.path_pos 歸零且換走下一條路
        if  self.path == PATH and self.path_pos >= ( len(PATH) - 2 ) :
            self.path_pos = 0
            which_path += 1
            print(which_path)
        #如果是PATH_OTHER且到達基地就將 self.path_pos 歸零且換走下一條路
        if  self.path == PATH_OTHER and self.path_pos >= ( len(PATH_OTHER) - 2 ):
            self.path_pos = 0
            which_path += 1
            print(which_path)
            


class EnemyGroup:
    def __init__(self):
        self.gen_count = 120
        self.gen_period = 120   # (unit: frame)
        self.reserved_members = []
        self.expedition = []  # don't change this line until you do the EX.3 

    def campaign(self):
        """
        Send an enemy to go on an expedition once 120 frame
        :return: None
        """
        # Hint: self.expedition.append(self.reserved_members.pop())
        
        #將self.reserved_members轉給self.expedition
        if self.is_empty() == False and self.gen_count == self.gen_period:
            self.expedition.append( self.reserved_members.pop() ) 
            self.gen_count = 0
        
        elif self.is_empty() == True and self.gen_count == self.gen_period:
            self.gen_count = 0

        else:
            self.gen_count += 1
        
    

    def generate(self, num):
        """
        Generate the enemies in this wave
        :param num: enemy number
        :return: None
        """
        #將Enemy object存進self.reserved_members
        for i in range (num):
            self.reserved_members.append(Enemy())

            


    def get(self):
        """
        Get the enemy list
        """
        
        return self.expedition

    def is_empty(self):
        """
        Return whether the enemy is empty (so that we can move on to next wave)
        """
        return False if self.reserved_members else True

    def retreat(self, enemy):
        """
        Remove the enemy from the expedition
        :param enemy: class Enemy()
        :return: None
        """
        self.expedition.remove(enemy)





